
import * as firebase from 'firebase/app';
import 'firebase/storage';
import 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyB819eV1m1ajBA3SeSRDPm3HeuJb0kyjn4",
  authDomain: "firegram-9878d.firebaseapp.com",
  projectId: "firegram-9878d",
  storageBucket: "firegram-9878d.appspot.com",
  messagingSenderId: "15916490093",
  appId: "1:15916490093:web:e75f285c6ed47a0e114e64"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const projectStorage = firebase.storage();
const projectFirestore = firebase.firestore();
const timestamp = firebase.firestore.FieldValue.serverTimestamp;

export { projectStorage, projectFirestore, timestamp };