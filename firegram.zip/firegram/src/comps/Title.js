import React from 'react';

const Title = () => {
  return (
    <div className="title">
      <h2>Flower Show</h2>
     </div>
  )
}

export default Title;